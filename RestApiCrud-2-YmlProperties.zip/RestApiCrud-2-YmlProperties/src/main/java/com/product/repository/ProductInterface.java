package com.product.repository;

import java.util.List;

import com.product.entity.Product;

public interface ProductInterface {
	 List<Product> allProduct(); //find all 
	 void addProduct(Product product);         // save product
	 Product findProduct(Integer id);     //find one product
	 void deleteProduct(Integer id);     // delete one product
	 Product updateProduct(Product product);     // change product
	 
}
