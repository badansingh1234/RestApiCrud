package com.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.entity.Product;
import com.product.repository.ProductInterface;
import com.product.repository.ProductRepo;

@Service
public class ProductService implements ProductInterface {

	@Autowired
	private ProductRepo repository;
	
	@Override
	public List<Product> allProduct() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		repository.save(product);
	}

	@Override
	public Product findProduct(Integer id) {
		// TODO Auto-generated method stub
		
		Optional < Product > optional = repository.findById(id);
		Product product = null;
        if (optional.isPresent()) {
        	product = optional.get();
        } else {
            throw new RuntimeException(" product not found for id :: " + id);
        }
		return product;
	}

	@Override
	public void deleteProduct(Integer id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		Product newProduct=  repository.findById(product.getId()).orElse(null);
		newProduct.setName(product.getName());
		newProduct.setQuantity(product.getQuantity());
		newProduct.setPrice(product.getPrice());
		return repository.save(newProduct);
	}

}
