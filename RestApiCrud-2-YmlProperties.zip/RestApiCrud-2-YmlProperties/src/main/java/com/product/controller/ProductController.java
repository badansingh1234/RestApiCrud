package com.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.product.entity.Product;
import com.product.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private  ProductService service;
	
	@GetMapping("/")     // welcome 
	public String home() {
		return "Welcome User...";
	}
	
	@PostMapping("/save")     // one product save
	public String saveProduct(@RequestBody Product product) {
		service.addProduct(product);
		return "Product Save Sucessfully...";
	}
	
	@GetMapping("/findAll")     // find all product
	public List<Product> findAllProduct(){
		return service.allProduct();
	}
	
	@GetMapping("/find/{id}")        // find one object
	public Product findOneProduct(@PathVariable int id) {
		return service.findProduct(id);
	}
	
	@DeleteMapping("/delete/{id}")     // delete one product
	public String deleteOneProduct(@PathVariable int id) {
		service.deleteProduct(id);
		return "Delete One Product Sucessfully...";
	}
	
	@PutMapping("/edit")             // edit product
	public Product editProduct(@RequestBody Product product) {
		product= service.updateProduct(product);
		return product;
	}
	
}
