package com.learn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.learn.entity.EmployeeDetail;
import com.learn.service.EmployeeService;

@RestController
//@RequestMapping(value = "/employee", method = RequestMethod.GET)
public class MyRestController {
	
	@Autowired
	private EmployeeService service;
	
	@GetMapping("/welcome")
	public String welcome() {
		return "welcome user.........";
	}
	
	@PostMapping("/save")
	public String  saveEmplyoee(@RequestBody EmployeeDetail employeeDetail) {
		service.createEmployee(employeeDetail);
		return "Added employee sucessfully..";
	}
	
	@GetMapping("/findAll")
	public List<EmployeeDetail> findAllEmployee(){
		return service.findAllEmployee();
	}
	
	@PutMapping("/update")
	public EmployeeDetail updateEmployees(@RequestBody EmployeeDetail employeeDetail) {
		employeeDetail =service.updateEmployee(employeeDetail);
		return employeeDetail;
	}
	
	@GetMapping("/findByid/{id}")
	public EmployeeDetail findByIdEmployee(@PathVariable int id) {
		return service.findByIdEmployee(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteEmployeeById(@PathVariable int id) {
		service.deleteEmployee(id);
		return "Delete Employee sucessfully...";
	}
}
