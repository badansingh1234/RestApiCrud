package com.learn.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="employee_details")
public class EmployeeDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String address;
	@Column(name="mobile_no")
	private String mobileNo;
	private String salary;
	
	public EmployeeDetail(){}

	public EmployeeDetail(String name, String address, String mobileNo, String salary) {
		super();
		this.name = name;
		this.address = address;
		this.mobileNo = mobileNo;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "EmployeeDetail [id=" + id + ", name=" + name + ", address=" + address + ", mobileNo=" + mobileNo
				+ ", salary=" + salary + "]";
	}
}
