package com.learn.service;

import java.util.List;

import com.learn.entity.EmployeeDetail;

public interface EmployeeInterFace {
	
	void createEmployee(EmployeeDetail employeeDetail);
	EmployeeDetail updateEmployee(EmployeeDetail employeeDetail);
	void deleteEmployee(int id);
	EmployeeDetail findByIdEmployee(int id);
	List<EmployeeDetail> findAllEmployee();
	
}
