package com.learn.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.ast.OpPlus;
import org.springframework.stereotype.Service;

import com.learn.entity.EmployeeDetail;
import com.learn.repository.EmployeeRepo;

@Service
public class EmployeeService implements EmployeeInterFace {

	@Autowired
	private EmployeeRepo repository;

	@Override
	public void createEmployee(EmployeeDetail employeeDetail) {
		this.repository.save(employeeDetail);
	}

	@Override
	public EmployeeDetail updateEmployee(EmployeeDetail employeeDetail) {
		// TODO Auto-generated method stub
		EmployeeDetail newEmployeeDetail = repository.findById(employeeDetail.getId()).orElse(null);
		newEmployeeDetail.setName(employeeDetail.getName());
		newEmployeeDetail.setAddress(employeeDetail.getAddress());
		newEmployeeDetail.setMobileNo(employeeDetail.getMobileNo());
		newEmployeeDetail.setSalary(employeeDetail.getSalary());
		return repository.save(newEmployeeDetail);
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	@Override
	public EmployeeDetail findByIdEmployee(int id) {
		// TODO Auto-generated method stub
	    Optional<EmployeeDetail> optional =	repository.findById(id);
	    EmployeeDetail employeeDetail = null;
	    if(optional.isPresent())
	    {
	    	employeeDetail = optional.get();
	    }else {
	    	throw new RuntimeException(" Employee not found for id :: " + id);
	    }
	    
	    return employeeDetail;
	}

	@Override
	public List<EmployeeDetail> findAllEmployee() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}
