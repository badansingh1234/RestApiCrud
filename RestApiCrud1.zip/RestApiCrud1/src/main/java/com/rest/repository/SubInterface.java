package com.rest.repository;

import java.util.List;

import com.rest.entity.Subject;

public interface SubInterface {
	List <Subject> getAllSubject();
    void saveSubject(Subject subject);
    Subject getSubjectById(int id);
    void deleteSubjectById(int id);
}
