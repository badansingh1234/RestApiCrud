package com.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rest.entity.Subject;
import com.rest.service.SubService;

@RestController
public class SubController {
	
	@Autowired
	private SubService service;
	
	@GetMapping("/")
	public String home() {
		return "Hello Ji...";
	}
	
	@PostMapping("/add")
	 public String addSubject(@RequestBody Subject subject) {
			 service.saveSubject(subject);
			 return "Add Subject Sucessfully....";
	  }
	
	@GetMapping("/findAll")
	public List<Subject> findAllSubject() {
		return service.getAllSubject();
	}
	
	@GetMapping("find/{id}")
	public Subject findSubjectOne(@PathVariable int id) {
		 return service.getSubjectById(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String  deleteSubject(@PathVariable int id) {
		service.deleteSubjectById(id);
		return "delete one subject sucessfully...";
	}
}
