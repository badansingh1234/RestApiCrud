package com.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.entity.Subject;
import com.rest.repository.SubInterface;
import com.rest.repository.SubRepo;

@Service
public class SubService implements SubInterface {

	@Autowired
	private SubRepo subRepo;
	
	@Override
	public List<Subject> getAllSubject() {
		// TODO Auto-generated method stub
		return	subRepo.findAll();
	}
	
	@Override
	public void saveSubject(Subject subject) {
		// TODO Auto-generated method stub
		this.subRepo.save(subject);
		
	}
	
	@Override
	public Subject getSubjectById(int id) {
		// TODO Auto-generated method stub
		Optional < Subject > optional = subRepo.findById(id);
        Subject subject = null;
        if (optional.isPresent()) {
        	subject = optional.get();
        } else {
            throw new RuntimeException(" Subject not found for id :: " + id);
        }
        return subject;
	}

	@Override
	public void deleteSubjectById(int id) {
		// TODO Auto-generated method stub
		this.subRepo.deleteById(id);
		
	}

}
