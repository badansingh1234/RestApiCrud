package com.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiCrud1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
